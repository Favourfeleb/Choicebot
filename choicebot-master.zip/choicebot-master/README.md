# Choicebot v1.1
## Author: github.com/thelinuxchoice
## IG: instagram.com/thelinuxchoice
### Don't copy this code without give me the credits, bitch! 
Choicebot is a bot written in Shell Script (the first one) to perform 'likes', 'comments' and 'follows' based on hastags.

![choice](https://user-images.githubusercontent.com/34893261/41206528-d1ac4302-6cdb-11e8-961e-a8b4830657d2.png)

### Usage:
```
git clone https://github.com/thelinuxchoice/choicebot
cd choicebot
chmod +x choicebot.sh
nano hashtags.txt (put your hashtags here)
./choicebot.sh
```

### Install requirements (Curl):

```
apt-get install curl
```

### Donate!
Support the authors:

<noscript><a href="https://liberapay.com/thelinuxchoice/donate"><img alt="Donate using Liberapay" src="https://liberapay.com/assets/widgets/donate.svg"></a></noscript>
